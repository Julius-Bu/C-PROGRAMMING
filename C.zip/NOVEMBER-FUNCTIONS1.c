//FUNCTIONS-1
#include <stdio.h>
int main()
{
	message();
	printf("\nJESUS is LORD!");
	main();
	return 0;
}
message()
{
	printf("\nJESUS is the Son of GOD.");
	//main();
}
