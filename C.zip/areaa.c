#include<stdio.h>
int main()
{
	const float pi=3.14;
	float area,r;
	printf("enter radius\n");
	scanf("%f",&r);
	area=pi*r*r;
	printf("area=%.2f",area);
	return 0;
	
	
	
	
	
	
	
}
