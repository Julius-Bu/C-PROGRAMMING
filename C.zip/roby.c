//BLESSED
#include <stdio.h>
int main()
{
	int i,j;
	for(i=0;i=0;i++)
	{
		for(j=0;j<1;j++)
		{
			printf("*");
		}
	}
	printf("\n");
	for(i=0;i<1;i++)
	{
		for(j=0;j<=1;j++)
		{
			printf("*");
		}
	}
	printf("\n");
	for(j=0;j<=2;j++)
	{
		printf("*");
	}
	printf("\n");
	for(j=0;j<=3;j++)
	{
		printf("*");
	}
	printf("\n");
	for(j=0;j<=4;j++)
	{
		printf("*");
	}
	printf("\n");
	for(j=0;j<=5;j++)
	{
		printf("*");
	}
	printf("\n");
	for(j=0;j<=6;j++)
	{
		printf("*");
	}
	printf("\n");
	return 0;
}
