//SUM OF TW0 NUMBERS
#include <stdio.h>
int main()
{
	int num1,num2,sum;
	printf("Please enter number1:");
	scanf("%d",&num1);
	printf("Please enter number2:");
	scanf("%d",&num2);
	sum=num1+num2;
	printf("sum = %d",sum);
	return 0;
}
