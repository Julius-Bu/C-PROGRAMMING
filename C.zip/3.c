//A C program displaying we must read our notes 1001 times.
#include <stdio.h>
int main()
{
	printf("\t\tWe\t\tmust\n");
	printf("read our\t\t\tnotes\n\n\n\n");
	printf("\t \"1001\"\n");
	printf("\t\t\t\ttimes");
	return 0;
}
