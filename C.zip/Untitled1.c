/* Program-2.3 - My First Program */
#include <stdio.h>
int main()
{
printf("Hello Word!\n");
printf("This is programming");
return 0;
}
