// A program to display a text
#include <stdio.h>
int main()
{
	printf("University of Moratuwa\n");
	printf("Katubedda, \nMoratuwa, \nSri Lanka \n");
	printf("...........................\n");
	printf("www.mrt.ac.1k");
	return 0;
	
}
