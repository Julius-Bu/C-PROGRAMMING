\\*My new program\\
#include<stdio.h>
int main()
{
	Printif
}
