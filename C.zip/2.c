//A C program that prints MAKERERE vertically
#include <stdio.h>
int main()
{
	printf("M\nA\nK\nE\nR\nE\nR\nE");
	return 0;
}
