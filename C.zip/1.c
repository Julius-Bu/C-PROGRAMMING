//A program that diplays your name and registration number
#include <stdio.h>
int main()
{
	printf("NAME: Viola,\tJulius,\tJoseph\n");
	printf("REGISTRATION NUMBER: 18/U/20882/EVE,\t18/U/20946/EVE,\t18/U/20942 ");
	return 0;
}
